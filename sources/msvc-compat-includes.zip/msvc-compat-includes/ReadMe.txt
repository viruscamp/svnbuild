
inttypes.h stdint.h are from https://github.com/chemeris/msinttypes/
copy to
C:\Program Files\Microsoft Visual Studio 9.0\VC\include
C:\Program Files\Microsoft Visual Studio 10.0\VC\include
donot overwrite

sdkddkver.h VersionHelpers.h winapifamily.h winpackagefamily.h
copy to
C:\Program Files\Microsoft SDKs\Windows\v6.0A\Include
C:\Program Files\Microsoft SDKs\Windows\v7.0A\Include
C:\Program Files\Microsoft SDKs\Windows\v7.1\Include
do overwrite


Actually, sdkddkver.h is from Windows10SDK, and change default values as winsdk-7.1

#define  _WIN32_WINNT   0x0601 // line 212
#define NTDDI_VERSION   0x06010000 // line 220
#define WINVER          0x0601 // line 229
#define _WIN32_IE       0x0800 // line 254