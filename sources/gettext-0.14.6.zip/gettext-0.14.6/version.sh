# Version number and release date.
VERSION_NUMBER=0.14.6
RELEASE_DATE=2006-06-21      # in "date +%Y-%m-%d" format
