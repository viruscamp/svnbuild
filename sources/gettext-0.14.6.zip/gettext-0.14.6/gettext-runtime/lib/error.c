#include "../../gettext-tools/lib/error.c"
